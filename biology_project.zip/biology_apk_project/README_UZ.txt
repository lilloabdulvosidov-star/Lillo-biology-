BIOLOGY 5–11 — Android loyiha manbalari

HOLATI: 0.1.0 dastlabki prototip.
- O'zbek kirill yozuvi.
- 5–11-sinflar menyusi.
- Har sinf uchun hozircha bittadan namunaviy mavzu.
- Har namunaviy mavzuga 10 tadan test.
- Dars va testlar internet talab qilmaydi.

MUHIM: ZIP tayyor APK emas. Uni telefonning o'zidan onlayn GitHub Actions orqali APK ga yig'ish uchun .github/workflows/build-apk.yml qo'shilgan.

FAQAT TELEFON ORQALI APK OLISH:
1. GitHub.com saytida akkaunt oching yoki мавжуд akkaунтга киринг.
2. New repository орқали янги repository яратинг (масалан biology-5-11).
3. ZIP архивни телефонда очиб, ичидаги biology_apk_project папкасидаги файлларни repository'га юкланг. .github папкасини ҳам юклаш шарт.
4. Repository'да Actions бўлимига киринг ва "Build Biology APK" workflow'ни танланг.
5. Run workflow тугмасини босинг.
6. Build муваффақиятли тугагач, иш натижасидаги Artifacts бўлимидан Biology-5-11-debug-apk ни юклаб олинг.
7. ZIP арxivini очинг ва app-debug.apk файлини телефонга ўрнатинг. Android сўраса, браузер ёки файл менежерига шу манбадан ўрнатиш рухсатини беринг.

Эслатма: Бу усул учун интернет ва GitHub аккаунти керак. Репозиторийни Public қилиш шарт эмас; Private ҳам бўлади.

Лойиҳада ҳозирча фақат намунавий мавзулар бор. Тўлиқ 5–11-синф дарсликлари ва барча мавзулар ҳали киритилмаган. Кейин уларни ишончли ўқув дастури асосида босқичма-босқич тўлдириш керак.
